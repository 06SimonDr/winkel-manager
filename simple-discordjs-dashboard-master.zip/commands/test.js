module.exports = {
	name: 'test',
	description: 'Ping!',
	aliases: ['ping'],
	ownerOnly: false,
	execute(client, message, args, prefix) {
		message.channel.send(`args ${args[0]}, prefix: ${prefix}, ping: ${Math.round(client.ws.ping)}ms`);
		message.channel.send('test')
	},
};