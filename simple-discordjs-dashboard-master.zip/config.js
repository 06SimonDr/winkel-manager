module.exports = {
  "token": "NjM3MzA0MjU3MDkwOTQ1MDI0.XbMN1w.RVWvrY8q52gSZ0U2OCqlz0PdGXY", // https://discordapp.com/developers/applications/ID/bot
  "mongodbUrl": "mongodb+srv://discord-bot:Pidag1403@cluster0.1qynp.mongodb.net/antiRaid", // Mongodb connection url.
  "id": "637304257090945024", // https://discordapp.com/developers/applications/ID/information
  "clientSecret": "vrbm9ntJCRY-CaogP4Dr-kNDGeij_zu5", // https://discordapp.com/developers/applications/ID/information
  "domain": "http://localhost",
  "port": 8000,
  "usingCustomDomain": false
};

/**
 * !!!
 * You need to add a redirect url to https://discordapp.com/developers/applications/ID/oauth2.
 * Format is: domain:port/callback example http://localhost:8080/callback
 * - Do not include port if the port is 80.
 * !!!
 */